%*********************************************************************************
%  Author: Jing Liang, Kangjia Qiao, Kunjie Yu
%  Last Edited: 10/07/2020
%  Email: yukunjie@zzu.edu.cn 
%  Reference: Parameters estimation of solar photovoltaic models via a
%  self-adaptive ensemble-based differential evolution, 2020
%*********************************************************************************
clc
clear all

warning off
format long;
addpath('Benchmark_Solar_Cell');
fun = @evaluate_normal_fitness;

popsize=30;

totaltime=30;

for func_flag= 1:3
    PV_Xrange;
    problem = func_flag;
    Maxfes=50000;
    time=1;
    
    while time <= totaltime
        
        
        tic
        rand('seed', sum(100 * clock));
        D = length(Xmax);
        n=D;
        p = zeros(n,D);
        lu = [Xmin;Xmax];
        uSet = zeros(popsize, n);
        % Initialize the main population
        p = repmat(lu(1, :), popsize, 1) + rand(popsize, n) .* (repmat(lu(2, :) - lu(1, :), popsize, 1));
        
        % Evaluate the objective function values
        FES=0;
        
        for i=1:popsize
            fit(i,:) = fun(p(i,:),func_flag);
            FES=FES+1;
            FE_best{func_flag}(time,FES) =  fit(i,:);
        end
        record(1) = min(fit);
        
        G=1;
        while FES < Maxfes
            G =G +1;
            pTemp = p;
            fitTemp = fit;
            
            for i = 1 : popsize
                
                % The three control parameter settings
                F    = [1.0 1.0 0.8];
                CR =   [0.1 0.9 0.2];
                
                % Uniformly and randomly select one of the control
                % parameter settings for each trial vector generation strategy
                paraIndex = floor(rand * length(F)) + 1;
                
                if rand> FES/ Maxfes  
                    
                    % Generate the trial vectors by the group1
                    u = group1(p, lu, i, F, CR, popsize, n, paraIndex);
                else
                    % Generate the trial vectors by the group1
                    [~,index_best] = min(fit);  
                    u = group2(p, lu, i, F, CR, popsize, n, paraIndex,index_best);
                end
                
                uSet(i,:) = u;
                
            end
            
            
            % Evaluate the trial vectors
            for i=1:popsize
                fitSet(i,:) = fun(uSet(i,:),func_flag);
                FES=FES+1;
                FE_best{func_flag}(time,FES) =  fitSet(i,:);
            end
            
            for i = 1 : popsize
                
                % Choose the better one from the trial vector and the target vector
                
                if fit(i) >= fitSet(i)
                    
                    pTemp(i, :) = uSet(i,:);
                    fitTemp(i, :) = fitSet(i,:);
                    
                end
                
            end
            
            p = pTemp;
            fit = fitTemp;
            
            record(G)=min(fit);
        end
        
        cputime(problem,time) = toc;
        best_index = find(min(fit)==fit);
        best_individual{problem,1}(time,:) = p(best_index(1),:);
        outcome(problem, time) = min(fit);
        fprintf('��%d������%d�����е�ֵ��%e\n',problem,time,outcome(problem, time))
        Record{problem,time}=record;
        time = time + 1;
        
    end
    mean_value=mean(outcome(problem,:),2);
    std_value = std(outcome(problem,:),0,2);
    fprintf('��%d������%d�����е�ƽ��ֵ��%e,������%e\n',problem,totaltime,mean_value,std_value)
    
end
for j =1:3
    final_data (j,1) = max(outcome(j,:));
    final_data (j,2) = min(outcome(j,:));
    final_data (j,3) = mean(outcome(j,:));
    final_data (j,4) = std(outcome(j,:));
end
save('SEDE','outcome','Record','best_individual','FE_best','cputime','final_data')
